export interface AuthState {
	isAuthenticated: boolean;
	phone: string;
}