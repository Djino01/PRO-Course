export function PrivacyPolicy() {
	return (
		<>
			<div>PrivacyPolicy</div>
		</>
	)
}

export default PrivacyPolicy;
