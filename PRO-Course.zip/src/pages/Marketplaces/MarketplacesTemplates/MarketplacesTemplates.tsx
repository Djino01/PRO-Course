import Headling from '../../../components/Headling/Headling';

const MarketplacesTemplates = () => {
	return(
		<div>
			<Headling appearance='big'>Маркетплейс шаблонов</Headling>
		</div>
	)
}

export default MarketplacesTemplates;